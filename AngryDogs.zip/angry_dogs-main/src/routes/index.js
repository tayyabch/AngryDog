import Home from "../views/Home";

let routes = [
    {
        path: "/",
        component: Home,
        layout: "main",
    },
];
export default routes;
