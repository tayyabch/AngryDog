// Root Reducer

import { combineReducers } from "redux";

export let rootReducer = combineReducers({
});

export default rootReducer;