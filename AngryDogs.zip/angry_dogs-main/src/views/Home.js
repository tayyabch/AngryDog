import About from "../components/Home/About";
import Faq from "../components/Home/Faq";
import RoadMap from "../components/Home/RoadMap";
import Sales from "../components/Home/Sales";

const MainView = (props) => {
    return (
        <>
            <About />
            <Sales />
            <RoadMap />
            <Faq />
        </>
    );
};

export default MainView;
