import Navbar from "./Navbar";
import banner_final from "../assets/img/banner-final.jpeg";
const Header = (props) => {
    return (
        <header className="header">
            <Navbar />
            <img src={banner_final} className="w-100" />
        </header>
    );
};

export default Header;
