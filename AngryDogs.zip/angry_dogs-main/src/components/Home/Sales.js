import { useState } from "react";
import { Button, Col, Container, Row } from "reactstrap";
import Web3 from "web3";
import EthUtil from 'ethereumjs-util';

import { ethers } from "ethers";

import {
    NFT_ADDRESS,
    NFT_ABI,
  } from "../../smartcontract/erc721";




    

const Sales = (props) => {
    let [counter, setCounter] = useState(1);
    let [address,setAddress] = useState("");

    const connectToMetaMask = async (e) => {
        e.preventDefault();

        if (typeof window.ethereum !== 'undefined') {
             // Instance web3 with the provided information
             var web3 = new Web3(window.ethereum);
             const net= await web3.eth.net.getNetworkType()
            
             if(net != "main"){
                alert("please connect to mainnet");
                return
             }
           
             try {
                 
                // Request account access
                await window.ethereum.enable();
                var accounts = await web3.eth.getAccounts();
                console.log(accounts)
                setAddress(accounts[0])
                return true
            } catch(e) {
                // User denied access
                return false
          }

      } else {
        alert(
          "Non-Ethereum browser detected. You should consider trying MetaMask!"
        );
      }
    }


    const batchMint = async (amount) => {
              // get the nonce - nonce is needed for security reasons. It keeps track of the number of
      // transactions sent from our address and prevents replay attacks.
      if (address === ""){
          alert("Metamask not connected");
          return
      }
      
      const web3 = new Web3(Web3.givenProvider);
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();


    

     
      const MyContract = new ethers.Contract(
        NFT_ADDRESS,
        NFT_ABI,
        signer
    );

     try {

         const todoList = new web3.eth.Contract(NFT_ABI, NFT_ADDRESS);

        let price = 0.02;//await MyContract.GetPrice;
        

      let nftPrice = price*amount;//await MyContract.GetPrice();


       let weibalance = await web3.eth.getBalance(address)
       let balance = web3.utils.fromWei(weibalance, "ether")
        if(balance < nftPrice){
            alert("not enough balance");
            return;
        }

      const transaction = await MyContract
      .mintNFT(amount, { value: (Web3.utils.toWei(nftPrice.toString(), 'ether')) })
      .then(function (txHash) {
      console.log("Transaction sent");
      alert("Transaction is done, NFT is saved in your Wallet");
      })
      .catch(function(err,msg){
        
          var msgs  = err
          var strmsg = JSON.stringify(msgs,null,2)
        
        var stringify = JSON.parse(strmsg);
        if(stringify.error.message != null){
            alert(stringify.error.message)
        }
       
  
          

       })
    } catch (err) {
        var resp = JSON.stringify(err)
        console.log(resp["reason"])
    }

      ////////////////
    //   try {
    //   //  const resp = await nftContract.mintNFT(2);  
    //     const gaslimit = await web3.eth.getBlock("latest").gasLimit;

    //     MyContract.methods.mintNFT(amount).send({
    //         from:address[0],   
    //         to: NFT_ADDRESS,         
    //         gas: gaslimit,
    //     }).on('transactionHash', function (resp) {
    //        console.log("resp",resp)
    //       })


    //      // console.log("transaction buy",resp);
    //   } catch (err) {
    //     console.log(err);
    //     if (err.code == 4001) {
    //       alert("Not enough tickets available");
    //     } else {
    //       alert(err);
    //     }
    // }
 
     
   }

    return (
        <>
            <Container>
                <div style={{ textAlign: "center" }} className="my-4">
                    <Button onClick={connectToMetaMask} className="btn-mint">{ (address.length) > 0 ? address:"Connect"  }</Button>
                    <br />
                    <div className="mt-4 mint-counter d-inline-block">
                        <div className="d-inline-flex align-items-center font-weight-bold">
                            <div className="counter">
                                <span
                                    className="mr-3 pointer"
                                    onClick={(e) =>
                                        setCounter((prevState) =>
                                            prevState != 1 ? prevState - 1 : 1
                                        )
                                    }
                                >
                                    -
                                </span>
                                {counter}
                                <span
                                    className="ml-3 pointer"
                                    onClick={(e) =>
                                        setCounter((prevState) =>
                                            prevState != 10 ? prevState + 1 : 10
                                        )
                                    }
                                >
                                    +
                                </span>
                            </div>
                            <span onClick={e => batchMint(counter)} className="text-uppercase px-5">Mint</span>
                        </div>
                    </div>
                </div>
            </Container>
        </>
    );
};

export default Sales;
