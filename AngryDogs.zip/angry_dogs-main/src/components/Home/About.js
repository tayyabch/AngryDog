import { Col, Container, Row } from "reactstrap";
import easygif from "../../assets/img/easygif.gif";
const About = (props) => {
    return (
        <>
            <section id="about">
                <Container>
                    <Row>
                        <Col md="6">
                            <h1 className="About-dogs">
                                What is Angry Dogs Club?
                            </h1>
                            <p className="detail">
                                Angry Dogs Club is a collection of 1,111 NFTs
                                living on the Ethereum Blockchain. Each dog
                                consists of a unique combination of a hat, face,
                                body, clothes, and background. There will also
                                be a small amount of super rare 1/1 Dogs. After
                                reveal you will be able to find more information
                                regarding rarities on rarity.tools
                            </p>
                            <h3 className="About-dogs">Available for Mint?</h3>
                            <p className="detail">
                                There will be 1,000 Angry Dogs available to mint
                                at launch, with 111 reserved for team members and
                                other community activities [promotions,
                                airdrops, etc]. Angry Dogs will be available to
                                mint for 0.06Ξ + Gas. Max 10 NFT of each
                                transaction
                            </p>
                            <h3 className="About-dogs">When is the reveal?</h3>
                            <p className="detail">
                                You'll be able to see your dog immediately after
                                minting. For more information Join our community
                                discord!
                            </p>
                            <h3 className="About-dogs">
                                Angry Dog Holders Benefits
                            </h3>
                            <p className="detail">
                                - We launch a merch store exclusively for Angry
                                Dogs Club holders.
                            </p>
                            <p className="detail">
                                - Money earnd from royalties (65%) will return
                                to Angry Dog holders each month in the shape of
                                Bonus.
                            </p>
                            <p className="detail">
                                - Will open a virtual private club exclusively
                                for the members of the Angry Dogs Club where our
                                members can participate in different activities
                                like: Game, contests and many more!
                            </p>
                            <h3 className="About-dogs">
                            Developing a earning game where our Angry Dog holders play and earn
                            </h3>
                            <p className="detail">
                                - How to play:
                            </p>
                            <p className="detail">
                                Enter  your  AngryDog token id and play there will be only one chance with one token id.
                            </p>
                            <p className="detail">
                                - For instance:
                            </p>
                            <p className="detail">
                                One holder holds 4 angry dogs there will be only 4 chance and other one is hold only one angry dog there will be only one chance.
                            </p>
                        </Col>
                        <Col md="6" className="mt-3 mt-md-0">
                            <img src={easygif} className="img-fluid" />
                        </Col>
                    </Row>
                </Container>
            </section>
        </>
    );
};

export default About;
