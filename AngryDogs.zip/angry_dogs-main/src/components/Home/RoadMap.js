import { Col, Container, Row } from "reactstrap";

const RoadMap = (props) => {
    return (
        <>
            <section id="road-map">
                <Container>
                    <h1 className="road-map">Road Map</h1>
                    <Row>
                        <Col>
                            <h2 className="description">25% Sold</h2>
                            <p className="short">
                                5 Angry Dogs NFTs Giveaway for our community
                                (Discord users and Twitter followers).
                            </p>
                            <h2 className="description">50% Sold</h2>
                            <p className="short">
                                6 Angry Dogs NFTs will be airdropped to random
                                token holders. Community Wallet filled with 3
                                ETH.
                            </p>
                            <h2 className="description">75% Sold</h2>
                            <p className="short">
                                Tag us on twitter with your angry dogs NFT. 3
                                tweets selected via twitterpicker dot com for a
                                2 ETH giveaway + Listing on Rarity.tools and we
                                will released our Backstory.
                            </p>
                            <h2 className="description">SOLD OUT</h2>
                            <p className="short">
                                We launch a merch store exclusively for Angry
                                Dogs Club holders. Special prizes for our
                                holders and Community wallet filled with 7 ETH.
                                Money earnd from royalty fees will be used to
                                buy floor priced.
                            </p>
                        </Col>
                    </Row>
                </Container>
            </section>
        </>
    );
};

export default RoadMap;
