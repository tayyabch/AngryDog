import React, { Component } from "react";
import { Card, CardBody, Col, Collapse, Container, Row } from "reactstrap";

class Faq extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
      Opened: false,
      // faq: null
      // collapse: null
    };
    this.toggle = this.toggle.bind(this);
  }
  toggle(faq) {
    if (this.state.Opened != faq) {
      this.setState({
        Opened: faq,
      });
    } else {
      this.setState({
        Opened: null,
      });
    }
  }
  render() {
    return (
      <>
        <Container>
          <Row style={{ textAlign: "center" }}>
            {/* <Col xs="12">  */}
            <Col xs="12" className=" d-flex justify-content-center flex-column">
              <h1 className="font-weight-bold mt-5 align-item-center text-white">
                <strong>FAQ</strong>
              </h1>
              <Card
                className="mb-2"
                onClick={(e) => {
                  this.toggle("faq1");
                }}
              >
                <div className="d-none d-lg-flex">
                  <h3
                    className="order-lg-1"
                    style={{ alignItems: "flex-start", padding: "25px 50px" }}
                  >
                    What is AngryDogs Club?
                  </h3>
                  <div
                    className="order-lg-2"
                    style={{
                      alignItems: "flex-end",
                      padding: "30px",
                      marginLeft: "auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>
                <div className=" d-flex d-lg-none">
                  <h3 style={{ textAlign: "left", padding: "12px" }}>
                    What is AngryDogs Club?
                  </h3>
                  <div
                    style={{
                      marginLeft: "auto",
                      padding: "12px",
                      margin: "auto 2px auto auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>

                <Collapse isOpen={this.state.Opened == "faq1"}>
                  <Card>
                    <CardBody className="detail text-dark">
                      Angry Dogs Club is a collection of 1,111 NFTs living on
                      the Ethereum Blockchain. Each dog consists of a unique
                      combination of a hat, face, body, clothes, and background.
                      There will also be a small amount of super rare 1/1 Dogs.
                    </CardBody>
                  </Card>
                </Collapse>
              </Card>

              <Card
                className="mb-2"
                onClick={(e) => {
                  this.toggle("faq2");
                }}
              >
                <div className="d-none d-lg-flex">
                  <h3
                    className="order-lg-1"
                    style={{ alignItems: "flex-start", padding: "25px 50px" }}
                  >
                    Will there be a pre-sale?
                  </h3>
                  <div
                    className="order-lg-2"
                    style={{
                      alignItems: "flex-end",
                      padding: "30px",
                      marginLeft: "auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>
                <div className=" d-flex d-lg-none">
                  <h3 style={{ textAlign: "left", padding: "12px" }}>
                    Will there be a pre-sale?
                  </h3>
                  <div
                    style={{
                      marginLeft: "auto",
                      padding: "12px",
                      margin: "auto 2px auto auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>

                <Collapse isOpen={this.state.Opened == "faq2"}>
                  <Card>
                    <CardBody className="detail text-dark">
                      There won't be any whitelist/presale. We reserved 111
                      AngryDogs for giveaway winners and marketing purposes.
                    </CardBody>
                  </Card>
                </Collapse>
              </Card>

              <Card
                className="mb-2"
                onClick={(e) => {
                  this.toggle("faq3");
                }}
              >
                <div className="d-none d-lg-flex">
                  <h3
                    className="order-lg-1"
                    style={{ alignItems: "flex-start", padding: "25px 50px" }}
                  >
                    Available for Mint?
                  </h3>
                  <div
                    className="order-lg-2"
                    style={{
                      alignItems: "flex-end",
                      padding: "30px",
                      marginLeft: "auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>
                <div className=" d-flex d-lg-none">
                  <h3 style={{ textAlign: "left", padding: "12px" }}>
                    Available for Mint?
                  </h3>
                  <div
                    style={{
                      marginLeft: "auto",
                      padding: "12px",
                      margin: "auto 2px auto auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>

                <Collapse isOpen={this.state.Opened == "faq3"}>
                  <Card>
                    <CardBody className="detail text-dark">
                      There will be 1,000 Angry Dogs available to mint at
                      launch.
                    </CardBody>
                  </Card>
                </Collapse>
              </Card>

              <Card
                className="mb-2"
                onClick={(e) => {
                  this.toggle("faq4");
                }}
              >
                <div className="d-none d-lg-flex">
                  <h3
                    className="order-lg-1"
                    style={{ alignItems: "flex-start", padding: "25px 50px" }}
                  >
                    Mint price?{" "}
                  </h3>
                  <div
                    className="order-lg-2"
                    style={{
                      alignItems: "flex-end",
                      padding: "30px",
                      marginLeft: "auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>
                <div className=" d-flex d-lg-none">
                  <h3 style={{ textAlign: "left", padding: "12px" }}>
                    Mint price?{" "}
                  </h3>
                  <div
                    style={{
                      marginLeft: "auto",
                      padding: "12px",
                      margin: "auto 2px auto auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>

                <Collapse isOpen={this.state.Opened == "faq4"}>
                  <Card>
                    <CardBody className="detail text-dark">
                      Angry Dogs will be available to mint for 0.06Ξ + Gas fee
                      Max 10 NFT of each transaction.
                    </CardBody>
                  </Card>
                </Collapse>
              </Card>

              <Card
                className="mb-2"
                onClick={(e) => {
                  this.toggle("faq5");
                }}
              >
                <div className="d-none d-lg-flex">
                  <h3
                    className="order-lg-1"
                    style={{ alignItems: "flex-start", padding: "25px 50px" }}
                  >
                    When is the reveal?{" "}
                  </h3>
                  <div
                    className="order-lg-2"
                    style={{
                      alignItems: "flex-end",
                      padding: "30px",
                      marginLeft: "auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>
                <div className=" d-flex d-lg-none">
                  <h3 style={{ textAlign: "left", padding: "12px" }}>
                    When is the reveal?{" "}
                  </h3>
                  <div
                    style={{
                      marginLeft: "auto",
                      padding: "12px",
                      margin: "auto 2px auto auto",
                    }}
                  >
                    <i className="fas fa-plus m-auto"></i>
                  </div>
                </div>

                <Collapse isOpen={this.state.Opened == "faq5"}>
                  <Card>
                    <CardBody className="detail text-dark">
                      <p>
                        {" "}
                        You'll be able to see your dog immediately after
                        minting.
                      </p>
                    </CardBody>
                  </Card>
                </Collapse>
              </Card>
            </Col>
            {/* </Col> */}
          </Row>
          <div className="d-block" style={{ paddingTop: "100px" }}>
            {" "}
          </div>
        </Container>
      </>
    );
  }
}
export default Faq;
