import { Container, Nav, Navbar as RC_Navbar, NavbarBrand } from "reactstrap";
const Navbar = (props) => {
    return (
        <RC_Navbar className="navbar-style">
            <Container>
                <NavbarBrand className="navbar-header">
                    <h2 className="logo m-0">Angry Dogs Club</h2>
                </NavbarBrand>
                <Nav className="navbar-right">
                    <li className="d-flex align-items-center">
                        <a
                            href="https://twitter.com/angrydogsnft"
                            className="btn btn-social-icon btn-twitter d-flex align-items-center justify-content-center"
                        >
                            <span
                                style={{ fontSize: 30 }}
                                className="fab fa-twitter"
                            />
                        </a>
                        <a
                            href=" https://discord.gg/kenR8kPZtN"
                            className="btn btn-social-icon btn-discord d-flex align-items-center justify-content-center"
                        >
                            <span
                                style={{ fontSize: 30 }}
                                className="fab fa-discord"
                            />
                        </a>
                    </li>
                </Nav>
            </Container>
        </RC_Navbar>
    );
};

export default Navbar;
