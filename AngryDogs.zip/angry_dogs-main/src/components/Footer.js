const Footer = (props) => {
    return (
        <>
            <footer className="page-footer font-small blue">
                <div className="footer-copyright text-center py-3">
                    2021 Copyrights © angrydogs.club. All rights reserverd.
                </div>
            </footer>
        </>
    );
};

export default Footer;
